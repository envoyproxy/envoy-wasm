fn main() {
    loop {
        println!("{}", "Hello World");
        break;
    }
}
