The index.html in this directory is rendered at https://bazelbuild.github.io/rules_rust/ via [github pages](https://help.github.com/articles/configuring-a-publishing-source-for-github-pages/).
