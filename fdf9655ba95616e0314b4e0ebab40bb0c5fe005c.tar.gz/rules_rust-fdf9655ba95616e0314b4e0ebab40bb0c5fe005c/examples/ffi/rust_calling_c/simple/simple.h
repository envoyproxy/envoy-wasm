#include <stdint.h>

const int64_t SIMPLE_VALUE = 43;
