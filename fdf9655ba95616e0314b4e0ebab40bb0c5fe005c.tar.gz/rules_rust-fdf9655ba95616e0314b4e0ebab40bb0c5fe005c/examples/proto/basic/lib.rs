extern crate common_proto_rust;

pub fn do_something(x: &common_proto_rust::Config) -> bool {
    true
}
